#!/bin/sh
rm -fr uploads/ templates/ static/ models.py views.py *.pyc clean.sh
