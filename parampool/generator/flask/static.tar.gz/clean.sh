#!/bin/sh
rm -rf uploads/ templates/ static/ model.py controller.py *.pyc clean.sh
